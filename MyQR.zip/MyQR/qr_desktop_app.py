import qrcode
from tkinter import *
from tkinter import filedialog, messagebox, colorchooser
from PIL import Image

# Initialize the main window
root = Tk()
root.title("QR Code Generator by @m7mdnas")
root.geometry("420x580")
root.config(bg="#EAF9F6")

# Variables
url_var = StringVar()
save_path = StringVar()
qr_color = StringVar(value="#00BFA5")
lang = StringVar(value="ar")

# ---------------- LANGUAGE SYSTEM ----------------
texts = {
    "ar": {
        "title": "مولد رمز QR",
        "url_label": "أدخل الرابط:",
        "save_label": "اختر مكان حفظ الملف:",
        "browse": "تصفح...",
        "generate": "🔹 توليد الكود 🔹",
        "choose_color": "اختر اللون",
        "lang_btn": "Switch to English",
        "success": "✅ تم حفظ الكود بنجاح:",
        "warning_url": "الرجاء إدخال رابط أولاً",
        "warning_path": "الرجاء اختيار مكان الحفظ",
        "error": "حدث خطأ:",
    },
    "en": {
        "title": "QR Code Generator",
        "url_label": "Enter URL:",
        "save_label": "Choose Save Location:",
        "browse": "Browse...",
        "generate": "🔹 Generate QR 🔹",
        "choose_color": "Choose Color",
        "lang_btn": "تبديل إلى العربية",
        "success": "✅ QR saved successfully:",
        "warning_url": "Please enter a URL first",
        "warning_path": "Please choose a save location",
        "error": "Error:",
    },
}

# ---------------- FUNCTIONS ----------------
def switch_lang():
    """Toggle between Arabic and English"""
    if lang.get() == "ar":
        lang.set("en")
    else:
        lang.set("ar")
    refresh_ui()

def browse_location():
    """Open folder dialog to choose save path"""
    folder_selected = filedialog.askdirectory()
    if folder_selected:
        save_path.set(folder_selected)

def choose_color():
    """Open color picker"""
    color_code = colorchooser.askcolor(title="Select QR Color")
    if color_code[1]:
        qr_color.set(color_code[1])

def generate_qr():
    """Generate and save QR code"""
    url = url_var.get()
    path = save_path.get()

    if not url:
        messagebox.showwarning("Warning", texts[lang.get()]["warning_url"])
        return
    if not path:
        messagebox.showwarning("Warning", texts[lang.get()]["warning_path"])
        return

    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(url)
        qr.make(fit=True)

        img = qr.make_image(fill_color=qr_color.get(), back_color="white")

        save_file = f"{path}/qrcode.png"
        img.save(save_file)

        messagebox.showinfo("Done", f"{texts[lang.get()]['success']}\n{save_file}")

    except Exception as e:
        messagebox.showerror("Error", f"{texts[lang.get()]['error']}\n{e}")

def refresh_ui():
    """Refresh all labels/buttons to match current language"""
    t = texts[lang.get()]
    root.title(t["title"] + " by @m7mdnas")
    lbl_title.config(text=t["title"])
    lbl_url.config(text=t["url_label"])
    lbl_save.config(text=t["save_label"])
    btn_browse.config(text=t["browse"])
    btn_generate.config(text=t["generate"])
    btn_color.config(text=t["choose_color"])
    btn_lang.config(text=t["lang_btn"])

# ---------------- UI ELEMENTS ----------------
lbl_title = Label(root, text="", font=("Arial", 18, "bold"), bg="#EAF9F6", fg="#009688")
lbl_title.pack(pady=20)

lbl_url = Label(root, text="", font=("Arial", 12), bg="#EAF9F6")
lbl_url.pack()
Entry(root, textvariable=url_var, width=40, font=("Arial", 12)).pack(pady=5)

lbl_save = Label(root, text="", font=("Arial", 12), bg="#EAF9F6")
lbl_save.pack(pady=(15, 0))
Entry(root, textvariable=save_path, width=30, font=("Arial", 10)).pack(pady=5)
btn_browse = Button(root, text="", command=browse_location, bg="#009688", fg="white", width=15)
btn_browse.pack(pady=5)

btn_color = Button(root, text="", command=choose_color, bg="#00BFA5", fg="white", font=("Arial", 10), width=15)
btn_color.pack(pady=10)

btn_generate = Button(root, text="", command=generate_qr, bg="#00BFA5", fg="white", font=("Arial", 14, "bold"), width=20)
btn_generate.pack(pady=20)

btn_lang = Button(root, text="", command=switch_lang, bg="#009688", fg="white", font=("Arial", 10))
btn_lang.pack(side=BOTTOM, pady=(35,5))

lbl_footer = Label(root, text="by @m7mdnas", font=("Arial", 10, "italic"), bg="#EAF9F6", fg="#555555")
lbl_footer.pack(side=BOTTOM, pady=5)

# Initialize UI
refresh_ui()

# Run app
root.mainloop()
